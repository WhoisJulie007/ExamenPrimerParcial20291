//
//  tarjeta.swift
//  ExamenPrimerParcial20291
//
//  Created by WIN603 on 15/09/25.
//

import SwiftUI

struct tarjeta: View {
    let banco : String
    let fotobanco : String
    let numero : String
    let nombre : String
    let logo : String
    let colortarjeta : Color
    @State var altura: CGFloat
    @State var efecto: CGFloat = 0
    
    var body: some View {
        VStack(alignment: .leading){
            HStack{
                Text(banco)
                    .bold(true)
                Image(fotobanco)
                    .resizable()
                    .frame(width: 50, height: 50)
                Spacer()
                Image("tapClaro")
                    .resizable()
                    .frame(width: 50, height: 50)
            }
            .frame(width: 380, height: 60)
            HStack(){
                Text(numero)
                    .font(.system(size: 22, weight: .bold, design: .default))
                Spacer()
            }
            HStack(){
                Text(nombre)
                Spacer()
            }
            .frame(width: 380)
            Spacer()
            HStack{
                Button(action : {
                    withAnimation(){
                        if efecto == 0{
                            efecto = 180
                            altura = 150
                        }else{
                            efecto = 0
                            altura = 220
                        }
                    }
                    
                    
                }){
                    Image(systemName: "lock")
                    Text("Bloquear")
                }
                Spacer()
                if logo == "String"{
                    visa()
                }else{
                    Mastercard()
                }
            }
            
            
        }
        .padding(.leading)
        .foregroundColor(Color.white)
        .frame(width: 390, height: altura)
        .background(colortarjeta)
        .cornerRadius(20)
        .rotation3DEffect(.degrees(efecto), axis: (x: 0, y: 1, z: 0))
    }
}

#Preview {
    tarjeta(banco: "Mercado Pago", fotobanco: "mercadopago", numero: "1234 5678 9012", nombre: "Julia Maydeli Castan Pacheco", logo: "String",colortarjeta: Color.blue, altura: 220, efecto: 0)
}
