//
//  ExamenPrimerParcial20291App.swift
//  ExamenPrimerParcial20291
//
//  Created by WIN603 on 15/09/25.
//

import SwiftUI

@main
struct ExamenPrimerParcial20291App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
